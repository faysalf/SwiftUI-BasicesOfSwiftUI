//
//  DatePicker_CalenderApp.swift
//  DatePicker-Calender
//
//  Created by Reserveit Support on 28/5/23.
//

import SwiftUI

@main
struct DatePicker_CalenderApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
